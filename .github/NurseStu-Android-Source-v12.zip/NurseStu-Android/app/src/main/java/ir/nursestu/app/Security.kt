package ir.nursestu.app

import androidx.compose.runtime.mutableIntStateOf
import java.security.MessageDigest

/** Simple app lock (PIN). It locks the screen only; it does not encrypt the stored data. */
object AppLock {
    /** Incremented by MainActivity when the app returns after being in the background for a while. */
    val relock = mutableIntStateOf(0)

    fun hash(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(("nursestu-pin:$pin").toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
