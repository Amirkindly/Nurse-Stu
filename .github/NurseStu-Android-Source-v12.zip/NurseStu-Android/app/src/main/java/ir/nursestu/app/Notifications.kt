package ir.nursestu.app

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import java.util.Calendar

/** Parses "08:00", "8:30", "۰۸:۳۰" ... into (hour, minute) or null. */
fun parseTime(raw: String): Pair<Int, Int>? {
    val s = buildString {
        for (ch in raw.trim()) append(
            when (ch) {
                in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                '\u066B', '\u060C', '\u066C', '.', ':' -> ':'
                else -> ch
            }
        )
    }
    val parts = s.split(":")
    if (parts.size != 2) return null
    val h = parts[0].trim().toIntOrNull() ?: return null
    val m = parts[1].trim().toIntOrNull() ?: return null
    if (h !in 0..23 || m !in 0..59) return null
    return h to m
}

fun hasNotifPermission(c: Context): Boolean =
    Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

object Reminders {
    const val CHANNEL = "nursestu_reminders"
    private const val PREFS = "nurse_stu_alarms"

    private class Spec(val title: String, val text: String, val hour: Int, val minute: Int)

    private fun specs(d: AppData): List<Spec> {
        val out = mutableListOf<Spec>()
        d.patients.forEach { p ->
            p.medications.forEach { m ->
                if (m.remind) {
                    parseTime(m.time)?.let { (h, mi) ->
                        out += Spec(
                            "\uD83D\uDC8A ${m.name}",
                            listOf(p.name, m.dose, m.route).filter { it.isNotBlank() }.joinToString(" \u2022 "),
                            h, mi
                        )
                    }
                }
            }
        }
        d.reminders.filter { it.enabled }.forEach { r -> out += Spec(r.title, r.text, r.hour, r.minute) }
        return out
    }

    fun ensureChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Nurse Stu reminders", NotificationManager.IMPORTANCE_HIGH)
                )
            }
        }
    }

    /** Schedules the next occurrence (strictly in the future) of a daily reminder. */
    fun scheduleOne(c: Context, code: Int, title: String, text: String, hour: Int, minute: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(c, ReminderReceiver::class.java)
            .putExtra("title", title).putExtra("text", text)
            .putExtra("code", code).putExtra("hour", hour).putExtra("minute", minute)
        val pend = PendingIntent.getBroadcast(c, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pend)
    }

    /** Cancels every previously scheduled alarm and schedules the current ones. */
    fun rebuild(c: Context, d: AppData) {
        try {
            ensureChannel(c)
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val prefs = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val old = prefs.getInt("count", 0)
            for (code in 0 until old) {
                val pend = PendingIntent.getBroadcast(
                    c, code, Intent(c, ReminderReceiver::class.java),
                    PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
                )
                if (pend != null) { am.cancel(pend); pend.cancel() }
            }
            val list = specs(d)
            list.forEachIndexed { code, s -> scheduleOne(c, code, s.title, s.text, s.hour, s.minute) }
            prefs.edit().putInt("count", list.size).apply()
        } catch (e: Exception) {
            // never crash the app because of reminders
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val title = i.getStringExtra("title") ?: return
        val text = i.getStringExtra("text") ?: ""
        val code = i.getIntExtra("code", 0)
        val hour = i.getIntExtra("hour", 8)
        val minute = i.getIntExtra("minute", 0)
        try {
            Reminders.ensureChannel(c)
            if (hasNotifPermission(c)) {
                val open = PendingIntent.getActivity(
                    c, 0,
                    Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, Reminders.CHANNEL) else Notification.Builder(c)
                b.setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setAutoCancel(true)
                    .setContentIntent(open)
                c.getSystemService(NotificationManager::class.java).notify(1000 + code, b.build())
            }
        } catch (e: Exception) {
            // ignore
        }
        Reminders.scheduleOne(c, code, title, text, hour, minute) // repeat tomorrow
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) Reminders.rebuild(c, Store.load(c))
    }
}
