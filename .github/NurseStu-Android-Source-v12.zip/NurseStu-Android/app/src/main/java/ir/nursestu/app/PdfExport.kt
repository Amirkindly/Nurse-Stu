package ir.nursestu.app

import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.ByteArrayOutputStream

object PdfExport {
    private const val W = 595
    private const val H = 842
    private const val M = 40

    private const val INK = 0xFF222222.toInt()
    private const val BRAND = 0xFF0B6AA8.toInt()
    private const val GRAY = 0xFF777777.toInt()
    private const val WARN = 0xFFD9822B.toInt()

    private class Block(
        val text: String,
        val size: Float = 11f,
        val bold: Boolean = false,
        val color: Int = INK,
        val before: Float = 4f
    )

    private fun vitalLine(v: VitalRecord): String {
        val parts = mutableListOf<String>()
        if (v.temp.isNotBlank()) parts += "T ${v.temp}"
        if (v.pulse.isNotBlank()) parts += "P ${v.pulse}"
        if (v.resp.isNotBlank()) parts += "R ${v.resp}"
        if (v.bp.isNotBlank()) parts += "BP ${v.bp}"
        if (v.spo2.isNotBlank()) parts += "SpO2 ${v.spo2}"
        val fbs = v.fbs.ifBlank { if (v.glucoseType == "fbs") v.glucose else "" }
        val pp = v.pp.ifBlank { if (v.glucoseType == "pp") v.glucose else "" }
        if (fbs.isNotBlank()) parts += "FBS $fbs"
        if (pp.isNotBlank()) parts += "2hPP $pp"
        if (v.glucose.isNotBlank() && v.glucoseType.isBlank()) parts += "BS ${v.glucose}"
        return parts.joinToString("  |  ")
    }

    fun patientPdf(p: Patient, en: Boolean): ByteArray {
        val t: Tr = { fa, e -> if (en) e else fa }
        val b = mutableListOf<Block>()
        b += Block("Nurse Stu — ${t("پرونده بیمار", "Patient record")}", 11f, color = GRAY)
        b += Block(p.name, 20f, true, BRAND, 6f)
        fun line(label: String, value: String) {
            b += Block("$label: ${value.ifBlank { "—" }}", 12f, before = 3f)
        }
        line(t("سن", "Age"), p.age)
        line(t("تشخیص ثبت‌شده", "Recorded diagnosis"), p.diagnosis)
        line(t("بخش", "Ward"), p.ward)
        line(t("پرستار بیمار", "Patient's nurse"), p.nurse)
        if (p.notes.isNotBlank()) line(t("یادداشت", "Notes"), p.notes)
        line(t("تاریخ تهیه", "Prepared"), nowStr())

        b += Block(t("شرح حال", "History"), 15f, true, BRAND, 16f)
        fun hist(label: String, value: String) {
            b += Block(label, 11f, true, GRAY, 8f)
            for (ln in value.ifBlank { "—" }.split("\n")) b += Block(ln.ifBlank { " " }, 12f, before = 1f)
        }
        hist(t("شکایت اصلی (CC)", "Chief complaint (CC)"), p.cc)
        hist(t("بیماری فعلی (Present Illness)", "Present illness (HPI)"), p.presentIllness)
        hist(t("سابقه بیماری", "Past medical history"), p.pastHistory)
        hist(t("سابقه دارویی", "Drug history"), p.drugHistory)
        hist(t("سابقه خانوادگی", "Family history"), p.familyHistory)
        hist(t("وضعیت روانی", "Mental status"), p.mentalStatus)

        b += Block(t("علائم حیاتی", "Vital signs"), 15f, true, BRAND, 16f)
        if (p.vitals.isEmpty()) b += Block("—", 12f)
        p.vitals.forEach { v ->
            b += Block(v.dateTime, 11f, true, GRAY, 8f)
            b += Block(vitalLine(v).ifBlank { "—" }, 12f, before = 1f)
            val f = findings(t, v)
            if (f.isNotEmpty()) b += Block(f.joinToString(" • "), 11f, color = WARN, before = 1f)
            if (v.note.isNotBlank()) b += Block(v.note, 11f, before = 1f)
        }

        b += Block(t("داروها و اقدامات", "Medications & tasks"), 15f, true, BRAND, 16f)
        if (p.medications.isEmpty()) b += Block("—", 12f)
        p.medications.forEach { m ->
            val main = listOf(m.name, m.amount, m.dose).filter { it.isNotBlank() }.joinToString(" — ")
            val meta = listOf(
                if (m.time.isNotBlank()) "${t("ساعت", "Time")}: ${m.time}" else "",
                if (m.route.isNotBlank()) "${t("روش", "Route")}: ${m.route}" else "",
                if (m.done) "${t("انجام شد", "Done")}: ${m.checkedAt}" else t("انجام نشده", "Not done")
            ).filter { it.isNotBlank() }.joinToString("  |  ")
            b += Block(main, 12f, true, before = 7f)
            b += Block(meta, 11f, before = 1f)
            if (m.note.isNotBlank()) b += Block(m.note, 11f, color = GRAY, before = 1f)
        }

        b += Block(
            t(
                "این سند آموزشی است و جایگزین پرونده رسمی بیمارستان یا قضاوت بالینی نیست.",
                "This document is educational and does not replace the official hospital record or clinical judgment."
            ),
            9f, color = GRAY, before = 20f
        )
        return render(b, en)
    }

    fun reportPdf(d: AppData, en: Boolean): ByteArray {
        val t: Tr = { fa, e -> if (en) e else fa }
        val b = mutableListOf<Block>()
        b += Block("Nurse Stu", 11f, color = GRAY)
        b += Block(t("گزارش پرستاری", "Nursing report"), 20f, true, BRAND, 6f)
        b += Block("${t("تاریخ تهیه", "Prepared")}: ${nowStr()}", 12f)

        val totalMeds = d.patients.sumOf { it.medications.size }
        val doneMeds = d.patients.sumOf { p -> p.medications.count { it.done } }
        b += Block(t("خلاصه وضعیت", "Summary"), 15f, true, BRAND, 16f)
        b += Block("${t("تعداد بیماران", "Patients")}: ${d.patients.size}", 12f)
        b += Block("${t("داروها و اقدامات تأییدشده", "Confirmed meds & tasks")}: $doneMeds / $totalMeds", 12f)
        b += Block("${t("چک‌لیست انجام‌شده", "Checklist done")}: ${d.tasks.count { it.done }} / ${d.tasks.size}", 12f)

        b += Block(t("بیماران", "Patients"), 15f, true, BRAND, 16f)
        if (d.patients.isEmpty()) b += Block("—", 12f)
        d.patients.forEach { p ->
            b += Block(p.name, 13f, true, before = 9f)
            b += Block(
                listOf(
                    "${t("سن", "Age")}: ${p.age.ifBlank { "—" }}",
                    "${t("بخش", "Ward")}: ${p.ward.ifBlank { "—" }}",
                    "${t("تشخیص", "Dx")}: ${p.diagnosis.ifBlank { "—" }}"
                ).joinToString("  |  "),
                11f, before = 1f
            )
            if (p.cc.isNotBlank()) b += Block("CC: ${p.cc}", 11f, before = 1f)
            p.vitals.firstOrNull()?.let { v ->
                b += Block("${t("آخرین علائم حیاتی", "Latest vitals")} (${v.dateTime}): ${vitalLine(v).ifBlank { "—" }}", 11f, before = 1f)
                val f = findings(t, v)
                if (f.isNotEmpty()) b += Block(f.joinToString(" • "), 10f, color = WARN, before = 1f)
            }
            b += Block("${t("داروها", "Meds")}: ${p.medications.count { it.done }} / ${p.medications.size} ${t("انجام شده", "done")}", 11f, before = 1f)
        }

        b += Block(t("چک‌لیست", "Checklist"), 15f, true, BRAND, 16f)
        if (d.tasks.isEmpty()) b += Block("—", 12f)
        d.tasks.forEach { tk ->
            b += Block("${if (tk.done) "[x]" else "[ ]"} ${tk.title}${if (tk.done && tk.checkedAt.isNotBlank()) " (${tk.checkedAt})" else ""}", 12f, before = 3f)
        }

        b += Block(t("گزارش‌های روزانه", "Daily reports"), 15f, true, BRAND, 16f)
        if (d.reports.isEmpty()) b += Block("—", 12f)
        d.reports.forEach { r ->
            b += Block("${shiftLabel(r.shift, t)} — ${r.dateTime}", 12f, true, before = 9f)
            if (r.patient.isNotBlank()) b += Block("${t("بیمار", "Patient")}: ${r.patient}", 11f, color = BRAND, before = 1f)
            for (ln in r.text.split("\n")) b += Block(ln.ifBlank { " " }, 12f, before = 1f)
        }
        return render(b, en)
    }

    private fun render(blocks: List<Block>, en: Boolean): ByteArray {
        val doc = PdfDocument()
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
        var canvas = page.canvas
        var y = M.toFloat()
        val bottom = H - M - 16f

        fun footer() {
            paint.textSize = 9f
            paint.isFakeBoldText = false
            paint.color = GRAY
            canvas.drawText("Nurse Stu  -  $pageNo", M.toFloat(), H - 22f, paint)
        }

        for (blk in blocks) {
            paint.textSize = blk.size
            paint.isFakeBoldText = blk.bold
            paint.color = blk.color
            val layout = StaticLayout.Builder
                .obtain(blk.text, 0, blk.text.length, paint, W - 2 * M)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(if (en) TextDirectionHeuristics.LTR else TextDirectionHeuristics.RTL)
                .setLineSpacing(2f, 1f)
                .build()
            y += blk.before
            if (y + layout.height > bottom && y > M + 1f) {
                footer()
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
                canvas = page.canvas
                y = M.toFloat()
            }
            canvas.save()
            canvas.translate(M.toFloat(), y)
            layout.draw(canvas)
            canvas.restore()
            y += layout.height
        }
        footer()
        doc.finishPage(page)
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }
}
