package ir.nursestu.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class Patient(
    val name: String,
    val age: String,
    val diagnosis: String,
    val ward: String,
    val notes: String,
    val medications: List<Medication> = emptyList()
)

data class Medication(
    val name: String,
    val amount: String,
    val dose: String,
    val time: String,
    val route: String,
    val note: String,
    val done: Boolean = false,
    val checkedAt: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NurseStuApp(applicationContext) }
    }
}

private fun loadPatients(context: Context): List<Patient> {
    return try {
        val raw = context.getSharedPreferences("nurse_stu_store", Context.MODE_PRIVATE)
            .getString("patients_json", null) ?: return emptyList()
        val type = object : TypeToken<List<Patient>>() {}.type
        Gson().fromJson<List<Patient>>(raw, type) ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }
}

private fun savePatients(context: Context, patients: List<Patient>) {
    try {
        context.getSharedPreferences("nurse_stu_store", Context.MODE_PRIVATE)
            .edit().putString("patients_json", Gson().toJson(patients)).apply()
    } catch (e: Exception) {
        // Keep the app usable; persistence errors should be surfaced in a production release.
    }
}

@Composable
fun NurseStuApp(context: Context) {
    var isEnglish by remember {
        mutableStateOf(context.getSharedPreferences("nurse_stu_store", Context.MODE_PRIVATE)
            .getBoolean("english", false))
    }
    var patients by remember { mutableStateOf(loadPatients(context)) }
    var screen by remember { mutableStateOf("home") }
    var selectedIndex by remember { mutableIntStateOf(-1) }
    var showPatientDialog by remember { mutableStateOf(false) }
    var showMedicationDialog by remember { mutableStateOf(false) }

    fun updatePatients(newPatients: List<Patient>) {
        patients = newPatients
        savePatients(context, newPatients)
    }

    var restoreData by remember { mutableStateOf<List<Patient>?>(null) }

    val exportBackup = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    output.write(Gson().toJson(patients).toByteArray(Charsets.UTF_8))
                } ?: throw IllegalStateException("Cannot open backup destination")
                Toast.makeText(context, "پشتیبان با موفقیت ذخیره شد", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(context, "ذخیره پشتیبان ناموفق بود", Toast.LENGTH_LONG).show()
            }
        }
    }

    val importBackup = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw IllegalStateException("Cannot read backup")
                val type = object : TypeToken<List<Patient>>() {}.type
                val restored = Gson().fromJson<List<Patient>>(json, type)
                    ?: throw IllegalArgumentException("Invalid backup")
                restoreData = restored
            } catch (e: Exception) {
                Toast.makeText(context, "فایل پشتیبان معتبر نیست یا قابل خواندن نیست", Toast.LENGTH_LONG).show()
            }
        }
    }

    val t: (String, String) -> String = { fa, en -> if (isEnglish) en else fa }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF147D86),
            secondary = androidx.compose.ui.graphics.Color(0xFF4F9DA6),
            background = androidx.compose.ui.graphics.Color(0xFFF5F8FA),
            surface = androidx.compose.ui.graphics.Color.White
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides if (isEnglish) LayoutDirection.Ltr else LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                when (screen) {
                    "home" -> HomeScreen(
                        t = t,
                        isEnglish = isEnglish,
                        onLanguage = {
                            isEnglish = !isEnglish
                            context.getSharedPreferences("nurse_stu_store", Context.MODE_PRIVATE)
                                .edit().putBoolean("english", isEnglish).apply()
                        },
                        onNavigate = { screen = it },
                        onBackup = { exportBackup.launch("NurseStu-backup.json") },
                        onRestore = { importBackup.launch(arrayOf("application/json", "text/json", "text/plain")) }
                    )
                    "patients" -> PatientListScreen(
                        patients = patients,
                        t = t,
                        onBack = { screen = "home" },
                        onAdd = { showPatientDialog = true },
                        onSelect = { selectedIndex = it; screen = "detail" }
                    )
                    "detail" -> if (selectedIndex in patients.indices) {
                        PatientDetailScreen(
                            patient = patients[selectedIndex],
                            t = t,
                            onBack = { screen = "patients" },
                            onAddMedication = { showMedicationDialog = true },
                            onToggle = { medIndex, checked ->
                                val updated = patients.toMutableList()
                                val meds = updated[selectedIndex].medications.toMutableList()
                                meds[medIndex] = meds[medIndex].copy(
                                    done = checked,
                                    checkedAt = if (checked) java.text.SimpleDateFormat(
                                        "yyyy-MM-dd HH:mm", java.util.Locale.getDefault()
                                    ).format(java.util.Date()) else ""
                                )
                                updated[selectedIndex] = updated[selectedIndex].copy(medications = meds)
                                updatePatients(updated)
                            }
                        )
                    } else HomeScreen(t, isEnglish, { isEnglish = !isEnglish }, { screen = it }, {}, {})
                    "education" -> EducationScreen(t = t, onBack = { screen = "home" })
                    else -> SimpleInfoScreen(title = screenTitle(screen, t), t = t, onBack = { screen = "home" })
                }

                if (showPatientDialog) {
                    PatientDialog(
                        t = t,
                        onDismiss = { showPatientDialog = false },
                        onSave = { patient ->
                            updatePatients(patients + patient)
                            showPatientDialog = false
                        }
                    )
                }
                if (showMedicationDialog && selectedIndex in patients.indices) {
                    MedicationDialog(
                        t = t,
                        onDismiss = { showMedicationDialog = false },
                        onSave = { med ->
                            val updated = patients.toMutableList()
                            updated[selectedIndex] = updated[selectedIndex].copy(
                                medications = updated[selectedIndex].medications + med
                            )
                            updatePatients(updated)
                            showMedicationDialog = false
                        }
                    )
                }

                if (restoreData != null) {
                    AlertDialog(
                        onDismissRequest = { restoreData = null },
                        title = { Text(t("بازیابی پشتیبان؟", "Restore backup?")) },
                        text = { Text(t(
                            "بازیابی، اطلاعات فعلی این برنامه را با اطلاعات فایل پشتیبان جایگزین می‌کند. قبل از ادامه مطمئن شوید فایل درست را انتخاب کرده‌اید.",
                            "Restoring will replace the data currently in this app with the backup file. Make sure you selected the correct file."
                        )) },
                        confirmButton = {
                            Button(onClick = {
                                updatePatients(restoreData ?: emptyList())
                                restoreData = null
                                Toast.makeText(context, "اطلاعات پشتیبان بازیابی شد", Toast.LENGTH_LONG).show()
                            }) { Text(t("جایگزینی و بازیابی", "Replace and restore")) }
                        },
                        dismissButton = {
                            TextButton(onClick = { restoreData = null }) { Text(t("انصراف", "Cancel")) }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    t: (String, String) -> String,
    isEnglish: Boolean,
    onLanguage: () -> Unit,
    onNavigate: (String) -> Unit,
    onBackup: () -> Unit,
    onRestore: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Nurse Stu", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onLanguage) { Text(if (isEnglish) "فارسی" else "English") }
        }
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("✚", style = MaterialTheme.typography.displayMedium, color = MaterialTheme.colorScheme.primary)
                Text("Nurse Stu", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text(t("همراه آموزشی کارآموزان پرستاری و پزشکی", "A learning companion for nursing and medical students"), textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Text(
                    t("این اپ توسط امیررضا بهادری طراحی و ساخته شده است.",
                      "This app was designed and developed by Amirreza Bahadori."),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        Text(t("منوی اصلی", "Main menu"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        val entries = listOf(
            Triple("▣", t("مدیریت بیماران", "Patient management"), "patients"),
            Triple("＋", t("افزودن و پیگیری دارو", "Medication records"), "patients"),
            Triple("◷", t("برنامه دارویی", "Medication schedule"), "schedule"),
            Triple("✓", t("چک‌لیست اقدامات", "Task checklist"), "checklist"),
            Triple("▤", t("گزارش روزانه", "Daily reports"), "reports"),
            Triple("ℹ", t("اطلاعات و آموزش", "Information & tutorial"), "education"),
            Triple("⚙", t("تنظیمات", "Settings"), "settings")
        )
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            itemsIndexed(entries) { _, item ->
                Card(
                    Modifier.fillMaxWidth().clickable { onNavigate(item.third) },
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(item.first, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.width(12.dp))
                        Text(item.second, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        Text("‹", color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Text(t("پشتیبان‌گیری و بازیابی", "Backup & restore"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onBackup, modifier = Modifier.weight(1f)) {
                Text(t("ذخیره پشتیبان", "Back up"))
            }
            Button(onClick = onRestore, modifier = Modifier.weight(1f)) {
                Text(t("بازیابی اطلاعات", "Restore"))
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            t("نسخه آموزشی: فقط از داده ساختگی استفاده کنید؛ برای پرونده رسمی بیمارستانی طراحی نشده است.",
              "Educational build: use fictional data only; not designed for official hospital records."),
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun PatientListScreen(
    patients: List<Patient>,
    t: (String, String) -> String,
    onBack: () -> Unit,
    onAdd: () -> Unit,
    onSelect: (Int) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t("بیماران", "Patients"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onBack) { Text(t("بازگشت", "Back")) }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Text(t("+ افزودن بیمار", "+ Add patient")) }
        Spacer(Modifier.height(12.dp))
        if (patients.isEmpty()) {
            Text(t("هنوز بیماری ثبت نشده است.", "No patients have been added yet."), modifier = Modifier.padding(12.dp))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(patients) { index, patient ->
                    Card(Modifier.fillMaxWidth().clickable { onSelect(index) }) {
                        Column(Modifier.padding(16.dp)) {
                            Text(patient.name, fontWeight = FontWeight.Bold)
                            Text("${t("بیماری", "Diagnosis")}: ${patient.diagnosis.ifBlank { t("ثبت نشده", "Not entered") }}")
                            Text("${t("سن", "Age")}: ${patient.age.ifBlank { "—" }}")
                            Text("${t("موارد تأییدشده", "Confirmed items")}: ${patient.medications.count { it.done }} / ${patient.medications.size}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PatientDetailScreen(
    patient: Patient,
    t: (String, String) -> String,
    onBack: () -> Unit,
    onAddMedication: () -> Unit,
    onToggle: (Int, Boolean) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t("پرونده بیمار", "Patient record"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onBack) { Text(t("بازگشت", "Back")) }
        }
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(patient.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Text("${t("سن", "Age")}: ${patient.age}")
                Text("${t("تشخیص ثبت‌شده", "Recorded diagnosis")}: ${patient.diagnosis}")
                Text("${t("بخش", "Ward")}: ${patient.ward}")
                if (patient.notes.isNotBlank()) Text("${t("یادداشت", "Notes")}: ${patient.notes}")
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t("داروها و اقدامات", "Medications & tasks"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onAddMedication) { Text(t("+ افزودن", "+ Add")) }
        }
        if (patient.medications.isEmpty()) {
            Text(t("هنوز دارویی ثبت نشده است.", "No medication records yet."))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(patient.medications) { index, med ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = med.done, onCheckedChange = { onToggle(index, it) })
                                Column(Modifier.weight(1f)) {
                                    Text(med.name, fontWeight = FontWeight.Bold)
                                    Text("${t("مقدار", "Amount")}: ${med.amount} | ${t("دوز ثبت‌شده", "Recorded dose")}: ${med.dose}")
                                    Text("${t("ساعت", "Time")}: ${med.time} | ${t("روش/نوع تزریق", "Route/injection")}: ${med.route}")
                                }
                            }
                            if (med.note.isNotBlank()) Text("${t("توضیحات", "Notes")}: ${med.note}")
                            if (med.done) {
                                Text(t("✓ وضعیت توسط کاربر تأیید شده", "✓ Marked as confirmed by user"), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                if (med.checkedAt.isNotBlank()) Text("${t("زمان ثبت تأیید", "Confirmation time")}: ${med.checkedAt}", style = MaterialTheme.typography.bodySmall)
                            } else {
                                Text(t("هنوز تأیید نشده", "Not confirmed yet"), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PatientDialog(t: (String, String) -> String, onDismiss: () -> Unit, onSave: (Patient) -> Unit) {
    var name by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var diagnosis by remember { mutableStateOf("") }
    var ward by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(t("افزودن بیمار", "Add patient")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(t("نام یا کد مستعار بیمار *", "Patient name or alias *")) }, singleLine = true)
                OutlinedTextField(age, { age = it }, label = { Text(t("سن", "Age")) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(diagnosis, { diagnosis = it }, label = { Text(t("نوع بیماری / تشخیص ثبت‌شده", "Condition / recorded diagnosis")) })
                OutlinedTextField(ward, { ward = it }, label = { Text(t("بخش", "Ward")) })
                OutlinedTextField(notes, { notes = it }, label = { Text(t("یادداشت", "Notes")) })
            }
        },
        confirmButton = { Button(onClick = { if (name.isNotBlank()) onSave(Patient(name, age, diagnosis, ward, notes)) }) { Text(t("ذخیره", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(t("انصراف", "Cancel")) } }
    )
}

@Composable
fun MedicationDialog(t: (String, String) -> String, onDismiss: () -> Unit, onSave: (Medication) -> Unit) {
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var dose by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    var route by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(t("ثبت دارو / اقدام", "Add medication / task")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(t("نام دارو *", "Medication name *")) }, singleLine = true)
                OutlinedTextField(amount, { amount = it }, label = { Text(t("مقدار", "Amount")) }, singleLine = true)
                OutlinedTextField(dose, { dose = it }, label = { Text(t("دوز طبق دستور", "Dose as prescribed")) }, singleLine = true)
                OutlinedTextField(time, { time = it }, label = { Text(t("ساعت", "Time")) }, singleLine = true)
                OutlinedTextField(route, { route = it }, label = { Text(t("روش مصرف / نوع تزریق", "Route / injection type")) }, singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text(t("توضیحات", "Notes")) })
            }
        },
        confirmButton = { Button(onClick = { if (name.isNotBlank()) onSave(Medication(name, amount, dose, time, route, note)) }) { Text(t("ذخیره", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(t("انصراف", "Cancel")) } }
    )
}

@Composable
fun EducationScreen(t: (String, String) -> String, onBack: () -> Unit) {
    val sections = listOf(
        t("۱. شروع کار با Nurse Stu", "1. Getting started") to t(
            "در صفحه اصلی، منوی موردنظر را انتخاب کنید. از دکمه تغییر زبان در بالای صفحه می‌توانید بین فارسی و انگلیسی جابه‌جا شوید.",
            "Choose a section from the home menu. Use the language button at the top to switch between Persian and English."
        ),
        t("۲. ساخت پرونده بیمار", "2. Creating a patient record") to t(
            "وارد «مدیریت بیماران» شوید و «افزودن بیمار» را بزنید. نام یا کد مستعار لازم است. سن، تشخیص، بخش و یادداشت اختیاری‌اند. برای حفظ حریم خصوصی از نام و مشخصات واقعی استفاده نکنید.",
            "Open Patient Management and tap Add Patient. A name or alias is required. Age, diagnosis, ward and notes are optional. Use fictional data to protect privacy."
        ),
        t("۳. ثبت دارو یا اقدام", "3. Adding a medication or task") to t(
            "پرونده بیمار را باز کنید و افزودن را بزنید. نام دارو، مقدار، دوز طبق دستور معتبر، ساعت، روش مصرف یا نوع تزریق و توضیحات را ثبت کنید. برنامه هیچ دوز یا درمانی پیشنهاد نمی‌کند.",
            "Open a patient record and tap Add. Enter the medication name, amount, prescribed dose, time, route or injection type, and notes. The app does not recommend doses or treatments."
        ),
        t("۴. تأیید انجام با تیک", "4. Confirming completion") to t(
            "پس از بررسی و انجام واقعی اقدام طبق دستور و با نظارت لازم، تیک کنار همان مورد را بزنید. زمان ثبت تأیید ذخیره می‌شود. برداشتن تیک، تأیید را لغو می‌کند. تیک فقط ثبت کاربر است و جایگزین مستندسازی رسمی نیست.",
            "After the task has actually been completed and appropriately checked, tick its checkbox. The confirmation time is saved. Unticking removes the confirmation. This is a user log, not official clinical documentation."
        ),
        t("۵. ذخیره اطلاعات", "5. Saving data") to t(
            "پرونده‌ها و تیک‌های تأییدشده به‌طور خودکار در حافظه داخلی همین گوشی ذخیره می‌شوند و با بستن و بازکردن برنامه باقی می‌مانند. حذف داده برنامه یا پاک‌کردن حافظه آن می‌تواند اطلاعات را از بین ببرد. در این نسخه همگام‌سازی ابری و پشتیبان‌گیری وجود ندارد.",
            "Patient records and confirmation ticks are automatically saved on this phone and remain after closing and reopening the app. Clearing app data can erase them. This version has no cloud sync or backup."
        ),
        t("۶. اطلاعات و ایمنی", "6. Privacy and safety") to t(
            "این نسخه برای تمرین با داده ساختگی است، نه نگهداری پرونده واقعی بیمار. اطلاعات هویتی، عکس، شماره پرونده یا داده محرمانه وارد نکنید. اطلاعات دارو و دستور درمان باید از منبع مجاز بررسی شود و اپ جایگزین پزشک، پرستار مسئول یا سامانه بیمارستان نیست.",
            "This build is for practice with fictional data, not real patient records. Do not enter identifying details, photos, record numbers or confidential information. Medication details and orders must be checked against an authorized source. The app does not replace clinicians or hospital systems."
        ),
        t("۷. محدودیت‌های نسخه فعلی", "7. Current version limits") to t(
            "در این نسخه یادآور زمان‌دار، خروجی گزارش، حساب کاربری، رمزگذاری اختصاصی و همگام‌سازی بین دستگاه‌ها فعال نیست. منوهای نمایشی این بخش‌ها در نسخه‌های بعدی تکمیل می‌شوند.",
            "Scheduled notifications, report export, user accounts, dedicated encryption and cross-device sync are not active in this version. These menu sections are placeholders for future releases."
        )
    )
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(t("اطلاعات و آموزش", "Information & tutorial"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onBack) { Text(t("بازگشت", "Back")) }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            itemsIndexed(sections) { _, section ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(15.dp)) {
                        Text(section.first, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        Text(section.second, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun SimpleInfoScreen(title: String, t: (String, String) -> String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(t(
            "این بخش در نسخه اولیه هنوز فعال نشده است. اطلاعات بیماران و داروها را از بخش مدیریت بیماران ثبت کنید.",
            "This section is not active in the initial build yet. Add patient and medication records from Patient Management."
        ))
        Spacer(Modifier.height(16.dp))
        Button(onClick = onBack) { Text(t("بازگشت به منو", "Back to menu")) }
    }
}

fun screenTitle(screen: String, t: (String, String) -> String): String = when (screen) {
    "schedule" -> t("برنامه دارویی", "Medication schedule")
    "checklist" -> t("چک‌لیست اقدامات", "Task checklist")
    "reports" -> t("گزارش روزانه", "Daily reports")
    "settings" -> t("تنظیمات", "Settings")
    "medications" -> t("داروها", "Medications")
    "records" -> t("پرونده‌ها", "Records")
    "reminders" -> t("یادآورها", "Reminders")
    else -> t("بخش", "Section")
}
