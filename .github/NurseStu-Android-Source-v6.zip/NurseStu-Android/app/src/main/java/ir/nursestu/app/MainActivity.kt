package ir.nursestu.app

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

typealias Tr = (String, String) -> String

private val Brand = Color(0xFF0B6AA8)
private val BrandLight = Color(0xFFDDF0FA)
private val PageBg = Color(0xFFF2F7FA)
private val OkGreen = Color(0xFF2E9E6B)

class ConfirmState(val text: String, val onYes: () -> Unit)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        )
        setContent { NurseStuApp(applicationContext) }
    }
}

@Composable
fun NurseStuApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("nurse_stu_store", Context.MODE_PRIVATE) }
    var isEnglish by remember { mutableStateOf(prefs.getBoolean("english", false)) }
    var defaultNurse by remember { mutableStateOf(prefs.getString("default_nurse", "") ?: "") }
    var appData by remember { mutableStateOf(Store.load(context)) }
    var screen by remember { mutableStateOf("home") }
    var selectedIndex by remember { mutableIntStateOf(-1) }
    var patientDialog by remember { mutableStateOf<Int?>(null) }
    var medDialog by remember { mutableStateOf<Int?>(null) }
    var reportDialog by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf<ConfirmState?>(null) }
    var restoreData by remember { mutableStateOf<AppData?>(null) }

    val t: Tr = { fa, en -> if (isEnglish) en else fa }

    fun commit(n: AppData) {
        appData = n
        Store.save(context, n)
    }

    fun toast(msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
    }

    fun toggleLanguage() {
        isEnglish = !isEnglish
        prefs.edit().putBoolean("english", isEnglish).apply()
    }

    fun toggleMed(pi: Int, mi: Int, checked: Boolean) {
        val ps = appData.patients.toMutableList()
        val meds = ps[pi].medications.toMutableList()
        meds[mi] = meds[mi].copy(done = checked, checkedAt = if (checked) nowStr() else "")
        ps[pi] = ps[pi].copy(medications = meds)
        commit(appData.copy(patients = ps))
    }

    val exportBackup = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    output.write(Store.toBackupJson(appData).toByteArray(Charsets.UTF_8))
                } ?: throw IllegalStateException("Cannot open backup destination")
                toast(if (isEnglish) "Backup saved" else "پشتیبان با موفقیت ذخیره شد")
            } catch (e: Exception) {
                toast(if (isEnglish) "Backup failed" else "ذخیره پشتیبان ناموفق بود")
            }
        }
    }

    val importBackup = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw IllegalStateException("Cannot read backup")
                restoreData = Store.parseBackup(json)
            } catch (e: Exception) {
                toast(if (isEnglish) "Invalid or unreadable backup file" else "فایل پشتیبان معتبر نیست یا قابل خواندن نیست")
            }
        }
    }

    val doBackup = { exportBackup.launch("NurseStu-backup.json") }
    val doRestore = { importBackup.launch(arrayOf("application/json", "text/json", "text/plain", "application/octet-stream")) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Brand,
            onPrimary = Color.White,
            secondary = Color(0xFF14A9C2),
            secondaryContainer = Color(0xFFD3ECF8),
            onSecondaryContainer = Brand,
            primaryContainer = BrandLight,
            background = PageBg,
            surface = Color.White
        )
    ) {
        CompositionLocalProvider(
            LocalLayoutDirection provides if (isEnglish) LayoutDirection.Ltr else LayoutDirection.Rtl
        ) {
            BackHandler(enabled = screen != "home") {
                screen = if (screen == "detail") "patients" else "home"
            }

            val selectedTab = when (screen) {
                "detail" -> "patients"
                "education", "settings" -> "home"
                else -> screen
            }
            val tabs = listOf(
                Triple("home", t("خانه", "Home"), Icons.Filled.Home),
                Triple("patients", t("بیماران", "Patients"), Icons.Filled.Person),
                Triple("schedule", t("دارو", "Meds"), Icons.Filled.DateRange),
                Triple("checklist", t("چک‌لیست", "Tasks"), Icons.Filled.Check),
                Triple("reports", t("گزارش", "Reports"), Icons.Filled.Edit)
            )

            Scaffold(
                containerColor = PageBg,
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        tabs.forEach { tab ->
                            NavigationBarItem(
                                selected = selectedTab == tab.first,
                                onClick = { screen = tab.first },
                                icon = { Icon(tab.third, contentDescription = tab.second) },
                                label = { Text(tab.second, maxLines = 1, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            ) { inner ->
                Box(Modifier.padding(inner).fillMaxSize()) {
                    when (screen) {
                        "home" -> HomeScreen(
                            t = t,
                            data = appData,
                            onLanguage = { toggleLanguage() },
                            onNavigate = { screen = it },
                            onBackup = { doBackup() },
                            onRestore = { doRestore() }
                        )
                        "patients" -> PatientListScreen(
                            t = t,
                            patients = appData.patients,
                            onAdd = { patientDialog = -1 },
                            onOpen = { selectedIndex = it; screen = "detail" }
                        )
                        "detail" -> {
                            if (selectedIndex in appData.patients.indices) {
                                val pi = selectedIndex
                                PatientDetailScreen(
                                    t = t,
                                    patient = appData.patients[pi],
                                    onBack = { screen = "patients" },
                                    onEdit = { patientDialog = pi },
                                    onDelete = {
                                        confirm = ConfirmState(
                                            t("این پرونده بیمار حذف شود؟", "Delete this patient record?")
                                        ) {
                                            val ps = appData.patients.toMutableList()
                                            ps.removeAt(pi)
                                            commit(appData.copy(patients = ps))
                                            selectedIndex = -1
                                            screen = "patients"
                                        }
                                    },
                                    onAddMed = { medDialog = -1 },
                                    onToggle = { mi, checked -> toggleMed(pi, mi, checked) },
                                    onEditMed = { mi -> medDialog = mi },
                                    onDeleteMed = { mi ->
                                        confirm = ConfirmState(
                                            t("این مورد حذف شود؟", "Delete this item?")
                                        ) {
                                            val ps = appData.patients.toMutableList()
                                            val meds = ps[pi].medications.toMutableList()
                                            meds.removeAt(mi)
                                            ps[pi] = ps[pi].copy(medications = meds)
                                            commit(appData.copy(patients = ps))
                                        }
                                    }
                                )
                            } else {
                                PatientListScreen(
                                    t = t,
                                    patients = appData.patients,
                                    onAdd = { patientDialog = -1 },
                                    onOpen = { selectedIndex = it; screen = "detail" }
                                )
                            }
                        }
                        "schedule" -> ScheduleScreen(
                            t = t,
                            data = appData,
                            onToggle = { pi, mi, checked -> toggleMed(pi, mi, checked) }
                        )
                        "checklist" -> ChecklistScreen(
                            t = t,
                            tasks = appData.tasks,
                            onAdd = { title ->
                                commit(appData.copy(tasks = appData.tasks + TaskItem(title = title)))
                            },
                            onToggle = { i, checked ->
                                val ts = appData.tasks.toMutableList()
                                ts[i] = ts[i].copy(done = checked, checkedAt = if (checked) nowStr() else "")
                                commit(appData.copy(tasks = ts))
                            },
                            onDelete = { i ->
                                val ts = appData.tasks.toMutableList()
                                ts.removeAt(i)
                                commit(appData.copy(tasks = ts))
                            },
                            onClearDone = {
                                commit(appData.copy(tasks = appData.tasks.filter { !it.done }))
                            }
                        )
                        "reports" -> ReportsScreen(
                            t = t,
                            data = appData,
                            onAdd = { reportDialog = true },
                            onDelete = { i ->
                                confirm = ConfirmState(
                                    t("این گزارش حذف شود؟", "Delete this report?")
                                ) {
                                    val rs = appData.reports.toMutableList()
                                    rs.removeAt(i)
                                    commit(appData.copy(reports = rs))
                                }
                            }
                        )
                        "education" -> EducationScreen(t = t, onBack = { screen = "home" })
                        "settings" -> SettingsScreen(
                            t = t,
                            isEnglish = isEnglish,
                            onLanguage = { toggleLanguage() },
                            defaultNurse = defaultNurse,
                            onNurseChange = {
                                defaultNurse = it
                                prefs.edit().putString("default_nurse", it).apply()
                            },
                            onBackup = { doBackup() },
                            onRestore = { doRestore() },
                            onClear = {
                                confirm = ConfirmState(
                                    t(
                                        "همه پرونده‌ها، چک‌لیست‌ها و گزارش‌ها برای همیشه پاک شوند؟",
                                        "Erase all patients, tasks and reports permanently?"
                                    )
                                ) {
                                    commit(AppData())
                                    selectedIndex = -1
                                }
                            },
                            onBack = { screen = "home" }
                        )
                        else -> Unit
                    }
                }
            }

            // ---------- dialogs ----------
            val pd = patientDialog
            if (pd != null) {
                val initial = appData.patients.getOrNull(pd)
                PatientDialog(
                    t = t,
                    initial = initial,
                    defaultNurse = defaultNurse,
                    onDismiss = { patientDialog = null },
                    onSave = { p ->
                        if (initial == null) {
                            commit(appData.copy(patients = appData.patients + p))
                        } else {
                            val ps = appData.patients.toMutableList()
                            ps[pd] = p
                            commit(appData.copy(patients = ps))
                        }
                        patientDialog = null
                    }
                )
            }

            val md = medDialog
            if (md != null && selectedIndex in appData.patients.indices) {
                val pi = selectedIndex
                val initial = appData.patients[pi].medications.getOrNull(md)
                MedicationDialog(
                    t = t,
                    initial = initial,
                    onDismiss = { medDialog = null },
                    onSave = { med ->
                        val ps = appData.patients.toMutableList()
                        val meds = ps[pi].medications.toMutableList()
                        if (initial == null) meds.add(med) else meds[md] = med
                        ps[pi] = ps[pi].copy(medications = meds)
                        commit(appData.copy(patients = ps))
                        medDialog = null
                    }
                )
            }

            if (reportDialog) {
                ReportDialog(
                    t = t,
                    onDismiss = { reportDialog = false },
                    onSave = { r ->
                        commit(appData.copy(reports = listOf(r) + appData.reports))
                        reportDialog = false
                    }
                )
            }

            val cf = confirm
            if (cf != null) {
                AlertDialog(
                    onDismissRequest = { confirm = null },
                    title = { Text(t("تأیید", "Confirm")) },
                    text = { Text(cf.text) },
                    confirmButton = {
                        Button(onClick = {
                            cf.onYes()
                            confirm = null
                        }) { Text(t("بله، حذف شود", "Yes, delete")) }
                    },
                    dismissButton = {
                        TextButton(onClick = { confirm = null }) { Text(t("انصراف", "Cancel")) }
                    }
                )
            }

            val rd = restoreData
            if (rd != null) {
                AlertDialog(
                    onDismissRequest = { restoreData = null },
                    title = { Text(t("بازیابی پشتیبان؟", "Restore backup?")) },
                    text = {
                        Text(
                            t(
                                "بازیابی، اطلاعات فعلی این برنامه را با اطلاعات فایل پشتیبان جایگزین می‌کند. قبل از ادامه مطمئن شوید فایل درست را انتخاب کرده‌اید.",
                                "Restoring will replace the data currently in this app with the backup file. Make sure you selected the correct file."
                            )
                        )
                    },
                    confirmButton = {
                        Button(onClick = {
                            commit(rd)
                            restoreData = null
                            selectedIndex = -1
                            toast(if (isEnglish) "Backup restored" else "اطلاعات پشتیبان بازیابی شد")
                        }) { Text(t("جایگزینی و بازیابی", "Replace and restore")) }
                    },
                    dismissButton = {
                        TextButton(onClick = { restoreData = null }) { Text(t("انصراف", "Cancel")) }
                    }
                )
            }
        }
    }
}

// =====================================================================
// Shared building blocks
// =====================================================================

@Composable
fun SCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = if (onClick != null) modifier.clickable { onClick() } else modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        content = content
    )
}

@Composable
fun PageHeader(
    title: String,
    onBack: (() -> Unit)? = null,
    backLabel: String = "",
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = Brand,
            modifier = Modifier.weight(1f)
        )
        actions()
        if (onBack != null) {
            TextButton(onClick = onBack) { Text(backLabel) }
        }
    }
}

@Composable
fun EmptyState(text: String) {
    Box(Modifier.fillMaxWidth().padding(vertical = 32.dp), contentAlignment = Alignment.Center) {
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun StatTile(value: String, label: String, modifier: Modifier = Modifier) {
    SCard(modifier) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 12.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Brand)
            Text(label, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun MenuTile(icon: ImageVector, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    SCard(modifier, onClick) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 16.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(BrandLight),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Brand)
            }
            Spacer(Modifier.height(8.dp))
            Text(label, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun MedCard(
    t: Tr,
    med: Medication,
    owner: String?,
    onToggle: (Boolean) -> Unit,
    onEdit: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null
) {
    SCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = med.done, onCheckedChange = { onToggle(it) })
                Column(Modifier.weight(1f)) {
                    Text(
                        med.name,
                        fontWeight = FontWeight.Bold,
                        textDecoration = if (med.done) TextDecoration.LineThrough else null
                    )
                    if (owner != null) {
                        Text("${t("بیمار", "Patient")}: $owner", style = MaterialTheme.typography.bodySmall, color = Brand)
                    }
                    Text(
                        "${t("مقدار", "Amount")}: ${med.amount.ifBlank { "—" }} | ${t("دوز ثبت‌شده", "Recorded dose")}: ${med.dose.ifBlank { "—" }}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "${t("ساعت", "Time")}: ${med.time.ifBlank { "—" }} | ${t("روش", "Route")}: ${med.route.ifBlank { "—" }}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                if (onEdit != null) {
                    IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, contentDescription = t("ویرایش", "Edit"), tint = Brand) }
                }
                if (onDelete != null) {
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Filled.Delete, contentDescription = t("حذف", "Delete"), tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
            if (med.note.isNotBlank()) {
                Text("${t("توضیحات", "Notes")}: ${med.note}", style = MaterialTheme.typography.bodySmall)
            }
            if (med.done) {
                Text(
                    "${t("✓ تأیید شده توسط کاربر", "✓ Confirmed by user")}${if (med.checkedAt.isNotBlank()) " — ${med.checkedAt}" else ""}",
                    color = OkGreen,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Text(
                    t("هنوز تأیید نشده", "Not confirmed yet"),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

// =====================================================================
// Home
// =====================================================================

private class Tile(val icon: ImageVector, val label: String, val key: String)

@Composable
fun HomeScreen(
    t: Tr,
    data: AppData,
    onLanguage: () -> Unit,
    onNavigate: (String) -> Unit,
    onBackup: () -> Unit,
    onRestore: () -> Unit
) {
    val totalMeds = data.patients.sumOf { it.medications.size }
    val doneMeds = data.patients.sumOf { p -> p.medications.count { it.done } }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Nurse Stu",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Brand,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onLanguage) { Text(t("English", "فارسی")) }
            IconButton(onClick = { onNavigate("settings") }) {
                Icon(Icons.Filled.Settings, contentDescription = t("تنظیمات", "Settings"), tint = Brand)
            }
        }
        Spacer(Modifier.height(8.dp))

        SCard(Modifier.fillMaxWidth()) {
            Column(
                Modifier.fillMaxWidth().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(R.drawable.logo),
                    contentDescription = "Nurse Stu",
                    modifier = Modifier.size(96.dp).clip(RoundedCornerShape(22.dp))
                )
                Spacer(Modifier.height(10.dp))
                Text("Nurse Stu", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    t("همراه آموزشی کارآموزان پرستاری و پزشکی", "A learning companion for nursing and medical students"),
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    t(
                        "این اپ توسط امیررضا بهادری طراحی و ساخته شده است.",
                        "This app was designed and developed by Amirreza Bahadori."
                    ),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile(data.patients.size.toString(), t("بیمار", "Patients"), Modifier.weight(1f))
            StatTile(totalMeds.toString(), t("دارو و اقدام", "Meds & tasks"), Modifier.weight(1f))
            StatTile("$doneMeds/$totalMeds", t("تأییدشده", "Confirmed"), Modifier.weight(1f))
        }
        Spacer(Modifier.height(16.dp))

        Text(t("منوی اصلی", "Main menu"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))

        val tiles = listOf(
            Tile(Icons.Filled.Person, t("مدیریت بیماران", "Patient management"), "patients"),
            Tile(Icons.Filled.DateRange, t("برنامه دارویی", "Medication schedule"), "schedule"),
            Tile(Icons.Filled.Check, t("چک‌لیست اقدامات", "Task checklist"), "checklist"),
            Tile(Icons.Filled.Edit, t("گزارش روزانه", "Daily reports"), "reports"),
            Tile(Icons.Filled.Info, t("اطلاعات و آموزش", "Information & tutorial"), "education"),
            Tile(Icons.Filled.Settings, t("تنظیمات", "Settings"), "settings")
        )
        tiles.chunked(2).forEach { rowTiles ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowTiles.forEach { tile ->
                    MenuTile(tile.icon, tile.label, Modifier.weight(1f)) { onNavigate(tile.key) }
                }
                if (rowTiles.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(6.dp))
        Text(t("پشتیبان‌گیری و بازیابی", "Backup & restore"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onBackup, modifier = Modifier.weight(1f)) { Text(t("ذخیره پشتیبان", "Back up")) }
            Button(onClick = onRestore, modifier = Modifier.weight(1f)) { Text(t("بازیابی اطلاعات", "Restore")) }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            t(
                "نسخه آموزشی: فقط از داده ساختگی استفاده کنید؛ برای پرونده رسمی بیمارستانی طراحی نشده است.",
                "Educational build: use fictional data only; not designed for official hospital records."
            ),
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(16.dp))
    }
}

// =====================================================================
// Patients
// =====================================================================

@Composable
fun PatientListScreen(
    t: Tr,
    patients: List<Patient>,
    onAdd: () -> Unit,
    onOpen: (Int) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = patients.withIndex().filter { iv ->
        val p = iv.value
        query.isBlank() || listOf(p.name, p.diagnosis, p.ward, p.nurse).any { it.contains(query, ignoreCase = true) }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        PageHeader(t("بیماران", "Patients")) {
            Button(onClick = onAdd) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text(t("افزودن بیمار", "Add patient"))
            }
        }
        if (patients.isNotEmpty()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text(t("جستجو (نام، بخش، تشخیص، پرستار)", "Search (name, ward, diagnosis, nurse)")) }
            )
            Spacer(Modifier.height(8.dp))
        }
        if (filtered.isEmpty()) {
            EmptyState(
                if (patients.isEmpty()) t("هنوز بیماری ثبت نشده است.", "No patients have been added yet.")
                else t("موردی پیدا نشد.", "No matches found.")
            )
        } else {
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(filtered) { iv ->
                    val p = iv.value
                    SCard(Modifier.fillMaxWidth(), onClick = { onOpen(iv.index) }) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(p.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            if (p.ward.isNotBlank() || p.age.isNotBlank()) {
                                Text(
                                    listOf(
                                        if (p.ward.isNotBlank()) "${t("بخش", "Ward")}: ${p.ward}" else "",
                                        if (p.age.isNotBlank()) "${t("سن", "Age")}: ${p.age}" else ""
                                    ).filter { it.isNotBlank() }.joinToString(" | ")
                                )
                            }
                            if (p.diagnosis.isNotBlank()) Text("${t("تشخیص", "Diagnosis")}: ${p.diagnosis}")
                            if (p.nurse.isNotBlank()) {
                                Text("${t("پرستار", "Nurse")}: ${p.nurse}", color = Brand)
                            }
                            Text(
                                "${t("موارد تأییدشده", "Confirmed items")}: ${p.medications.count { it.done }} / ${p.medications.size}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PatientDetailScreen(
    t: Tr,
    patient: Patient,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onAddMed: () -> Unit,
    onToggle: (Int, Boolean) -> Unit,
    onEditMed: (Int) -> Unit,
    onDeleteMed: (Int) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        PageHeader(t("پرونده بیمار", "Patient record"), onBack, t("بازگشت", "Back"))
        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            item {
                SCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(patient.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        Text("${t("سن", "Age")}: ${patient.age.ifBlank { "—" }}")
                        Text("${t("تشخیص ثبت‌شده", "Recorded diagnosis")}: ${patient.diagnosis.ifBlank { "—" }}")
                        Text("${t("بخش", "Ward")}: ${patient.ward.ifBlank { "—" }}")
                        Text("${t("پرستار بیمار", "Patient's nurse")}: ${patient.nurse.ifBlank { "—" }}", color = Brand)
                        if (patient.notes.isNotBlank()) Text("${t("یادداشت", "Notes")}: ${patient.notes}")
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = onEdit) {
                                Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(t("ویرایش", "Edit"))
                            }
                            OutlinedButton(onClick = onDelete) {
                                Icon(Icons.Filled.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(t("حذف", "Delete"))
                            }
                        }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        t("داروها و اقدامات", "Medications & tasks"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    Button(onClick = onAddMed) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(t("افزودن", "Add"))
                    }
                }
            }
            if (patient.medications.isEmpty()) {
                item { EmptyState(t("هنوز دارویی ثبت نشده است.", "No medication records yet.")) }
            } else {
                itemsIndexed(patient.medications) { index, med ->
                    MedCard(
                        t = t,
                        med = med,
                        owner = null,
                        onToggle = { onToggle(index, it) },
                        onEdit = { onEditMed(index) },
                        onDelete = { onDeleteMed(index) }
                    )
                }
            }
        }
    }
}

// =====================================================================
// Schedule
// =====================================================================

private class SchedItem(val pi: Int, val mi: Int, val med: Medication, val patient: String)

@Composable
fun ScheduleScreen(t: Tr, data: AppData, onToggle: (Int, Int, Boolean) -> Unit) {
    var filter by remember { mutableIntStateOf(0) }
    val all = data.patients.flatMapIndexed { pi, p ->
        p.medications.mapIndexed { mi, m -> SchedItem(pi, mi, m, p.name) }
    }.sortedWith(compareBy({ it.med.time.isBlank() }, { it.med.time }))
    val shown = when (filter) {
        1 -> all.filter { !it.med.done }
        2 -> all.filter { it.med.done }
        else -> all
    }
    val labels = listOf(t("همه", "All"), t("در انتظار", "Pending"), t("تأییدشده", "Confirmed"))

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        PageHeader(t("برنامه دارویی", "Medication schedule"))
        Text(
            "${t("تأییدشده", "Confirmed")}: ${all.count { it.med.done }} / ${all.size}",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            labels.forEachIndexed { i, label ->
                FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(label) })
            }
        }
        Spacer(Modifier.height(8.dp))
        if (shown.isEmpty()) {
            EmptyState(
                if (all.isEmpty()) t("هنوز دارویی ثبت نشده است. از بخش بیماران اضافه کنید.", "No medications yet. Add them from Patients.")
                else t("موردی در این فیلتر نیست.", "Nothing in this filter.")
            )
        } else {
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(shown) { s ->
                    MedCard(
                        t = t,
                        med = s.med,
                        owner = s.patient,
                        onToggle = { onToggle(s.pi, s.mi, it) }
                    )
                }
            }
        }
    }
}

// =====================================================================
// Checklist
// =====================================================================

@Composable
fun ChecklistScreen(
    t: Tr,
    tasks: List<TaskItem>,
    onAdd: (String) -> Unit,
    onToggle: (Int, Boolean) -> Unit,
    onDelete: (Int) -> Unit,
    onClearDone: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    val doneCount = tasks.count { it.done }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        PageHeader(t("چک‌لیست اقدامات", "Task checklist")) {
            if (doneCount > 0) {
                TextButton(onClick = onClearDone) { Text(t("پاک‌کردن انجام‌شده‌ها", "Clear done")) }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text(t("اقدام جدید", "New task")) }
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (text.isNotBlank()) {
                    onAdd(text.trim())
                    text = ""
                }
            }) { Icon(Icons.Filled.Add, contentDescription = t("افزودن", "Add")) }
        }
        Spacer(Modifier.height(10.dp))
        if (tasks.isNotEmpty()) {
            Text("${t("انجام‌شده", "Done")}: $doneCount / ${tasks.size}", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { doneCount.toFloat() / tasks.size.toFloat() },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
        }
        if (tasks.isEmpty()) {
            EmptyState(t("هنوز اقدامی ثبت نشده است.", "No tasks yet."))
        } else {
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                itemsIndexed(tasks) { index, task ->
                    SCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = task.done, onCheckedChange = { onToggle(index, it) })
                            Column(Modifier.weight(1f)) {
                                Text(
                                    task.title,
                                    fontWeight = FontWeight.SemiBold,
                                    textDecoration = if (task.done) TextDecoration.LineThrough else null
                                )
                                if (task.done && task.checkedAt.isNotBlank()) {
                                    Text(task.checkedAt, style = MaterialTheme.typography.bodySmall, color = OkGreen)
                                }
                            }
                            IconButton(onClick = { onDelete(index) }) {
                                Icon(Icons.Filled.Delete, contentDescription = t("حذف", "Delete"), tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}

// =====================================================================
// Reports
// =====================================================================

private fun shiftLabel(code: String, t: Tr): String = when (code) {
    "evening" -> t("عصر", "Evening")
    "night" -> t("شب", "Night")
    else -> t("صبح", "Morning")
}

@Composable
fun ReportsScreen(t: Tr, data: AppData, onAdd: () -> Unit, onDelete: (Int) -> Unit) {
    val totalMeds = data.patients.sumOf { it.medications.size }
    val doneMeds = data.patients.sumOf { p -> p.medications.count { it.done } }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        PageHeader(t("گزارش روزانه", "Daily reports")) {
            Button(onClick = onAdd) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text(t("گزارش جدید", "New report"))
            }
        }
        SCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(t("خلاصه وضعیت", "Summary"), fontWeight = FontWeight.Bold)
                Text("${t("تعداد بیماران", "Patients")}: ${data.patients.size}")
                Text("${t("داروها و اقدامات تأییدشده", "Confirmed meds & tasks")}: $doneMeds / $totalMeds")
                Text("${t("چک‌لیست انجام‌شده", "Checklist done")}: ${data.tasks.count { it.done }} / ${data.tasks.size}")
            }
        }
        Spacer(Modifier.height(10.dp))
        if (data.reports.isEmpty()) {
            EmptyState(t("هنوز گزارشی ثبت نشده است.", "No reports yet."))
        } else {
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                itemsIndexed(data.reports) { index, r ->
                    SCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("${shiftLabel(r.shift, t)} — ${r.dateTime}", fontWeight = FontWeight.Bold)
                                    if (r.patient.isNotBlank()) {
                                        Text("${t("بیمار", "Patient")}: ${r.patient}", color = Brand, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                                IconButton(onClick = { onDelete(index) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = t("حذف", "Delete"), tint = MaterialTheme.colorScheme.error)
                                }
                            }
                            Text(r.text)
                        }
                    }
                }
            }
        }
    }
}

// =====================================================================
// Settings & education
// =====================================================================

@Composable
fun SettingsScreen(
    t: Tr,
    isEnglish: Boolean,
    onLanguage: () -> Unit,
    defaultNurse: String,
    onNurseChange: (String) -> Unit,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onClear: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
    ) {
        PageHeader(t("تنظیمات", "Settings"), onBack, t("بازگشت", "Back"))

        SCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(t("زبان", "Language"), fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("English", modifier = Modifier.weight(1f))
                    Switch(checked = isEnglish, onCheckedChange = { onLanguage() })
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        SCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(t("نام پرستار پیش‌فرض", "Default nurse name"), fontWeight = FontWeight.Bold)
                Text(
                    t(
                        "این نام هنگام افزودن بیمار جدید به‌صورت خودکار در فیلد پرستار نوشته می‌شود.",
                        "This name is pre-filled in the nurse field when adding a new patient."
                    ),
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = defaultNurse,
                    onValueChange = onNurseChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text(t("نام پرستار", "Nurse name")) }
                )
            }
        }
        Spacer(Modifier.height(10.dp))

        SCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(t("پشتیبان‌گیری و بازیابی", "Backup & restore"), fontWeight = FontWeight.Bold)
                Text(
                    t(
                        "پشتیبان شامل بیماران، داروها، چک‌لیست و گزارش‌هاست. فایل را در جای امن نگه دارید.",
                        "The backup includes patients, medications, checklist and reports. Keep the file somewhere safe."
                    ),
                    style = MaterialTheme.typography.bodySmall
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onBackup, modifier = Modifier.weight(1f)) { Text(t("ذخیره پشتیبان", "Back up")) }
                    Button(onClick = onRestore, modifier = Modifier.weight(1f)) { Text(t("بازیابی", "Restore")) }
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        SCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(t("پاک‌کردن اطلاعات", "Erase data"), fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) {
                    Text(t("حذف همه اطلاعات برنامه", "Delete all app data"), color = MaterialTheme.colorScheme.error)
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        SCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(t("درباره برنامه", "About"), fontWeight = FontWeight.Bold)
                Text("Nurse Stu — ${t("نسخه", "version")} 2.0")
                Text(
                    t("طراحی و ساخت: امیررضا بهادری", "Designed and developed by Amirreza Bahadori"),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun EducationScreen(t: Tr, onBack: () -> Unit) {
    val sections = listOf(
        t("۱. شروع کار با Nurse Stu", "1. Getting started") to t(
            "با نوار پایین بین بخش‌های خانه، بیماران، دارو، چک‌لیست و گزارش جابه‌جا شوید. از صفحه اصلی می‌توانید زبان را بین فارسی و انگلیسی تغییر دهید و به تنظیمات و این راهنما بروید.",
            "Use the bottom bar to switch between Home, Patients, Meds, Tasks and Reports. On the home screen you can change the language and open Settings and this guide."
        ),
        t("۲. ساخت پرونده بیمار", "2. Creating a patient record") to t(
            "وارد «بیماران» شوید و «افزودن بیمار» را بزنید. نام یا کد مستعار لازم است. سن، تشخیص، بخش، نام پرستار بیمار و یادداشت اختیاری‌اند. با دکمه ویرایش یا حذف در پرونده می‌توانید اطلاعات را اصلاح کنید. برای حفظ حریم خصوصی از نام و مشخصات واقعی استفاده نکنید.",
            "Open Patients and tap Add patient. A name or alias is required. Age, diagnosis, ward, the patient's nurse and notes are optional. Use Edit or Delete inside the record to change it. Use fictional data to protect privacy."
        ),
        t("۳. ثبت دارو یا اقدام", "3. Adding a medication or task") to t(
            "پرونده بیمار را باز کنید و افزودن را بزنید. نام دارو، مقدار، دوز طبق دستور معتبر، ساعت (مثلاً 08:00)، روش مصرف یا نوع تزریق و توضیحات را ثبت کنید. هر مورد قابل ویرایش و حذف است. برنامه هیچ دوز یا درمانی پیشنهاد نمی‌کند.",
            "Open a patient record and tap Add. Enter the medication name, amount, prescribed dose, time (e.g. 08:00), route or injection type and notes. Each item can be edited or deleted. The app does not recommend doses or treatments."
        ),
        t("۴. تأیید انجام با تیک", "4. Confirming completion") to t(
            "پس از بررسی و انجام واقعی اقدام طبق دستور و با نظارت لازم، تیک کنار همان مورد را بزنید. زمان ثبت تأیید ذخیره می‌شود و با برداشتن تیک لغو می‌شود. تیک فقط ثبت کاربر است و جایگزین مستندسازی رسمی نیست.",
            "After the task has actually been completed and appropriately checked, tick its checkbox. The confirmation time is saved and removed if you untick. This is a user log, not official clinical documentation."
        ),
        t("۵. برنامه دارویی", "5. Medication schedule") to t(
            "این بخش داروهای همه بیماران را بر اساس ساعت مرتب نشان می‌دهد. می‌توانید فقط موارد در انتظار یا تأییدشده را فیلتر کنید و همان‌جا تیک بزنید.",
            "This screen lists the medications of all patients sorted by time. Filter pending or confirmed items and tick them right there."
        ),
        t("۶. چک‌لیست و گزارش روزانه", "6. Checklist and daily reports") to t(
            "در چک‌لیست اقدامات عمومی شیفت را اضافه و تیک بزنید. در گزارش روزانه با انتخاب شیفت، گزارش متنی ثبت کنید؛ خلاصه وضعیت بالای صفحه به‌صورت خودکار به‌روز می‌شود.",
            "In the checklist, add and tick general shift tasks. In Daily reports, choose a shift and write a text report; the summary at the top updates automatically."
        ),
        t("۷. ذخیره و پشتیبان‌گیری", "7. Saving and backup") to t(
            "همه اطلاعات به‌طور خودکار در حافظه داخلی گوشی ذخیره می‌شوند. حذف داده برنامه یا پاک‌کردن حافظه آن می‌تواند اطلاعات را از بین ببرد. از «ذخیره پشتیبان» یک فایل JSON بگیرید و در جای امن نگه دارید؛ پس از نصب مجدد با «بازیابی» برگردانید.",
            "All data is saved automatically on this phone. Clearing app data can erase it. Use Back up to create a JSON file and keep it somewhere safe; restore it after reinstalling."
        ),
        t("۸. اطلاعات و ایمنی", "8. Privacy and safety") to t(
            "این نسخه برای تمرین با داده ساختگی است، نه نگهداری پرونده واقعی بیمار. اطلاعات هویتی، عکس، شماره پرونده یا داده محرمانه وارد نکنید. اطلاعات دارو و دستور درمان باید از منبع مجاز بررسی شود و اپ جایگزین پزشک، پرستار مسئول یا سامانه بیمارستان نیست. فایل پشتیبان رمزگذاری نشده است.",
            "This build is for practice with fictional data, not real patient records. Do not enter identifying details, photos, record numbers or confidential information. Medication details and orders must be checked against an authorized source. The app does not replace clinicians or hospital systems. The backup file is not encrypted."
        ),
        t("۹. محدودیت‌های نسخه فعلی", "9. Current version limits") to t(
            "یادآور زمان‌دار (نوتیفیکیشن)، خروجی PDF گزارش، حساب کاربری، رمزگذاری و همگام‌سازی بین دستگاه‌ها هنوز فعال نیست.",
            "Timed reminders (notifications), PDF report export, user accounts, encryption and cross-device sync are not available yet."
        )
    )
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        PageHeader(t("اطلاعات و آموزش", "Information & tutorial"), onBack, t("بازگشت", "Back"))
        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 16.dp)
        ) {
            items(sections) { section ->
                SCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(15.dp)) {
                        Text(section.first, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        Text(section.second, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

// =====================================================================
// Dialogs
// =====================================================================

@Composable
fun PatientDialog(
    t: Tr,
    initial: Patient?,
    defaultNurse: String,
    onDismiss: () -> Unit,
    onSave: (Patient) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var age by remember { mutableStateOf(initial?.age ?: "") }
    var diagnosis by remember { mutableStateOf(initial?.diagnosis ?: "") }
    var ward by remember { mutableStateOf(initial?.ward ?: "") }
    var nurse by remember { mutableStateOf(initial?.nurse ?: defaultNurse) }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) t("افزودن بیمار", "Add patient") else t("ویرایش بیمار", "Edit patient")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    label = { Text(t("نام یا کد مستعار بیمار *", "Patient name or alias *")) }
                )
                OutlinedTextField(
                    value = age, onValueChange = { age = it }, singleLine = true,
                    label = { Text(t("سن", "Age")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(
                    value = diagnosis, onValueChange = { diagnosis = it },
                    label = { Text(t("نوع بیماری / تشخیص ثبت‌شده", "Condition / recorded diagnosis")) }
                )
                OutlinedTextField(
                    value = ward, onValueChange = { ward = it },
                    label = { Text(t("بخش", "Ward")) }
                )
                OutlinedTextField(
                    value = nurse, onValueChange = { nurse = it }, singleLine = true,
                    label = { Text(t("نام پرستار بیمار", "Patient's nurse")) }
                )
                OutlinedTextField(
                    value = notes, onValueChange = { notes = it },
                    label = { Text(t("یادداشت", "Notes")) }
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) {
                    val base = initial ?: Patient()
                    onSave(
                        base.copy(
                            name = name.trim(),
                            age = age.trim(),
                            diagnosis = diagnosis.trim(),
                            ward = ward.trim(),
                            nurse = nurse.trim(),
                            notes = notes.trim()
                        )
                    )
                }
            }) { Text(t("ذخیره", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(t("انصراف", "Cancel")) } }
    )
}

@Composable
fun MedicationDialog(
    t: Tr,
    initial: Medication?,
    onDismiss: () -> Unit,
    onSave: (Medication) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var amount by remember { mutableStateOf(initial?.amount ?: "") }
    var dose by remember { mutableStateOf(initial?.dose ?: "") }
    var time by remember { mutableStateOf(initial?.time ?: "") }
    var route by remember { mutableStateOf(initial?.route ?: "") }
    var note by remember { mutableStateOf(initial?.note ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (initial == null) t("ثبت دارو / اقدام", "Add medication / task") else t("ویرایش دارو / اقدام", "Edit medication / task"))
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    label = { Text(t("نام دارو *", "Medication name *")) }
                )
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it }, singleLine = true,
                    label = { Text(t("مقدار", "Amount")) }
                )
                OutlinedTextField(
                    value = dose, onValueChange = { dose = it }, singleLine = true,
                    label = { Text(t("دوز طبق دستور", "Dose as prescribed")) }
                )
                OutlinedTextField(
                    value = time, onValueChange = { time = it }, singleLine = true,
                    label = { Text(t("ساعت (مثلاً 08:00)", "Time (e.g. 08:00)")) }
                )
                OutlinedTextField(
                    value = route, onValueChange = { route = it }, singleLine = true,
                    label = { Text(t("روش مصرف / نوع تزریق", "Route / injection type")) }
                )
                OutlinedTextField(
                    value = note, onValueChange = { note = it },
                    label = { Text(t("توضیحات", "Notes")) }
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) {
                    val base = initial ?: Medication()
                    onSave(
                        base.copy(
                            name = name.trim(),
                            amount = amount.trim(),
                            dose = dose.trim(),
                            time = time.trim(),
                            route = route.trim(),
                            note = note.trim()
                        )
                    )
                }
            }) { Text(t("ذخیره", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(t("انصراف", "Cancel")) } }
    )
}

@Composable
fun ReportDialog(t: Tr, onDismiss: () -> Unit, onSave: (ReportItem) -> Unit) {
    var shift by remember { mutableStateOf("morning") }
    var patient by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    val shifts = listOf("morning", "evening", "night")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(t("گزارش جدید", "New report")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(t("شیفت", "Shift"), fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    shifts.forEach { code ->
                        FilterChip(
                            selected = shift == code,
                            onClick = { shift = code },
                            label = { Text(shiftLabel(code, t)) }
                        )
                    }
                }
                OutlinedTextField(
                    value = patient, onValueChange = { patient = it }, singleLine = true,
                    label = { Text(t("نام بیمار (اختیاری)", "Patient (optional)")) }
                )
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, minLines = 4,
                    label = { Text(t("متن گزارش *", "Report text *")) }
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                if (text.isNotBlank()) {
                    onSave(ReportItem(dateTime = nowStr(), shift = shift, patient = patient.trim(), text = text.trim()))
                }
            }) { Text(t("ذخیره", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(t("انصراف", "Cancel")) } }
    )
}
