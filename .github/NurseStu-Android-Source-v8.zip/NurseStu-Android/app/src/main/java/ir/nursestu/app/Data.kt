package ir.nursestu.app

import android.content.Context
import com.google.gson.Gson
import com.google.gson.JsonParser
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Medication(
    val name: String = "",
    val amount: String = "",
    val dose: String = "",
    val time: String = "",
    val route: String = "",
    val note: String = "",
    val done: Boolean = false,
    val checkedAt: String = ""
)

data class VitalRecord(
    val dateTime: String = "",
    val temp: String = "",
    val pulse: String = "",
    val resp: String = "",
    val bp: String = "",
    val spo2: String = "",
    val note: String = ""
)

data class Patient(
    val name: String = "",
    val age: String = "",
    val diagnosis: String = "",
    val ward: String = "",
    val notes: String = "",
    val nurse: String = "",
    val medications: List<Medication> = emptyList(),
    // --- شرح حال (History) ---
    val cc: String = "",
    val presentIllness: String = "",
    val pastHistory: String = "",
    val drugHistory: String = "",
    val familyHistory: String = "",
    val mentalStatus: String = "",
    // --- علائم حیاتی (TPR + BP + SpO2) ---
    val vitals: List<VitalRecord> = emptyList()
)

data class TaskItem(
    val title: String = "",
    val done: Boolean = false,
    val checkedAt: String = ""
)

data class ReportItem(
    val dateTime: String = "",
    val shift: String = "morning",
    val patient: String = "",
    val text: String = ""
)

data class AppData(
    val version: Int = 3,
    val patients: List<Patient> = emptyList(),
    val tasks: List<TaskItem> = emptyList(),
    val reports: List<ReportItem> = emptyList()
)

fun nowStr(): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())

object Store {
    private const val PREFS = "nurse_stu_store"
    private val gson = Gson()

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(c: Context): AppData {
        return try {
            val p = prefs(c)
            val patients: List<Patient> = p.getString("patients_json", null)?.let {
                gson.fromJson<List<Patient>>(it, object : TypeToken<List<Patient>>() {}.type)
            } ?: emptyList()
            val tasks: List<TaskItem> = p.getString("tasks_json", null)?.let {
                gson.fromJson<List<TaskItem>>(it, object : TypeToken<List<TaskItem>>() {}.type)
            } ?: emptyList()
            val reports: List<ReportItem> = p.getString("reports_json", null)?.let {
                gson.fromJson<List<ReportItem>>(it, object : TypeToken<List<ReportItem>>() {}.type)
            } ?: emptyList()
            AppData(patients = patients, tasks = tasks, reports = reports)
        } catch (e: Exception) {
            AppData()
        }
    }

    fun save(c: Context, d: AppData) {
        try {
            prefs(c).edit()
                .putString("patients_json", gson.toJson(d.patients))
                .putString("tasks_json", gson.toJson(d.tasks))
                .putString("reports_json", gson.toJson(d.reports))
                .apply()
        } catch (e: Exception) {
            // keep the app usable
        }
    }

    fun toBackupJson(d: AppData): String = gson.toJson(d)

    /** Accepts both the old format (a plain list of patients) and the new full format. */
    fun parseBackup(json: String): AppData {
        val el = JsonParser.parseString(json)
        if (el.isJsonArray) {
            val list = gson.fromJson<List<Patient>>(el, object : TypeToken<List<Patient>>() {}.type)
            return AppData(patients = list ?: emptyList())
        }
        if (el.isJsonObject) {
            val d = gson.fromJson(el, AppData::class.java)
            return AppData(
                patients = d.patients ?: emptyList(),
                tasks = d.tasks ?: emptyList(),
                reports = d.reports ?: emptyList()
            )
        }
        throw IllegalArgumentException("Invalid backup")
    }
}
